# Run Bot on Your PC (Local)

## First time setup

1. **Double-click `run_local.bat`**
2. **Log in** – Enter your phone number (with country code, e.g. +254...) and the code from Telegram
3. When you see `Bot is running. Watching Avibum -> KE7ZONE`, the bot is active
4. Press **Ctrl+C** to stop
5. Next time, just double-click **run_local.bat** again – no login needed

## Normal use

- **Start:** Double-click `run_local.bat`
- **Stop:** Press **Ctrl+C** in the terminal window

Keep the terminal window open while the bot runs. Your PC must stay on.
